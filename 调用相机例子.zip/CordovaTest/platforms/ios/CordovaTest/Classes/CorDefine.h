//
//  CorDefine.h
//  CordovaTest
//
//  Created by Mac on 15/12/29.
//
//

#import <Foundation/Foundation.h>

#ifndef CorDefine
#define CorDefine

/**
 * NativeResult:               向原生传递的成功与失败
 * NativeControllerTitle:      原生Controller标题
 * CControllerClassName:       原生需要转到到的界面
 * NativeSkipAction:           原生跳转操作是pop,push,还是present操作
 * NativeRendData:             向原生发送的数据
 */
extern NSString *const NativeResult;
extern NSString *const NativeControllerTitle;
extern NSString *const NativeControllerClassName;
extern NSString *const NativeSkipAction;
extern NSString *const NativeSendData;

#endif

