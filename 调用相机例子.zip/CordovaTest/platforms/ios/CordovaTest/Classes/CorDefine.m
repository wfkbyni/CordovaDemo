//
//  CorDefine.m
//  CordovaTest
//
//  Created by Mac on 15/12/29.
//
//

#import "CorDefine.h"

#pragma mark 

NSString *const NativeResult = @"NativeResult";
NSString *const NativeControllerTitle = @"NativeControllerTitle";
NSString *const NativeControllerClassName = @"NativeControllerClassName";
NSString *const NativeSkipAction = @"NativeSkipAction";
NSString *const NativeSendData = @"NativeSendData";
