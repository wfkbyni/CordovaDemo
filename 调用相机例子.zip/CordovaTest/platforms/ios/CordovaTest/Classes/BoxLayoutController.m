//
//  BoxLayoutController.m
//  CordovaTest
//
//  Created by Mac on 15/12/29.
//
//

#import "BoxLayoutController.h"

@implementation BoxLayoutController

- (void)viewDidLoad{
    self.wwwFolderName = @"www";
    self.startPage = @"index5.html";
    
    [super viewDidLoad];
}

@end
