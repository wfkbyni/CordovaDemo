//
//  ShowDataContrller.h
//  CordovaTest
//
//  Created by Mac on 15/12/29.
//
//

#import <Cordova/CDVViewController.h>
#import <UIKit/UIKit.h>

@interface ShowDataContrller : UIViewController

@end
