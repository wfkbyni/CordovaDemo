//
//  ShowDataContrller.m
//  CordovaTest
//
//  Created by Mac on 15/12/29.
//
//

#import "ShowDataContrller.h"

@implementation ShowDataContrller

- (void)viewDidLoad{
//    self.wwwFolderName = @"";
//    self.startPage = @"http://apple.com.cn";
    [super viewDidLoad];
    
}

@end
