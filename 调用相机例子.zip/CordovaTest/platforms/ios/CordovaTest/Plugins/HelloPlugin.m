//
//  HelloPlugin.m
//  CordovaTest
//
//  Created by Mac on 15/12/15.
//
//

#import "HelloPlugin.h"
#import <objc/runtime.h>

#import "TestViewController.h"
#import "Test2ViewController.h"

@implementation HelloPlugin

- (void)nativeFunction:(id)arguments{
 
    CDVInvokedUrlCommand *command = arguments;
    
    NSLog(@"%@  %@   %@   %@",    command.arguments, command. methodName, command.className, command.callbackId);
    
    if (command.arguments != nil && command.arguments.count > 0) {
        NSDictionary *dic = command.arguments.firstObject;
        
        NSString *result = [dic objectForKey:NativeResult];
        NSString *controllerTitle = [dic objectForKey:NativeControllerTitle];
        NSString *controllerClassName = [dic objectForKey:NativeControllerClassName];
        NSString *skipAction = [dic objectForKey:NativeSkipAction];
        NSString *sendData = [dic objectForKey:NativeSendData];
        
        NSLog(@"result:%@ \n reveiceData : %@",result, sendData);
        
        UINavigationController *nav = [HelloPlugin getRootViewController];
        
        // 这里pop时，如果controllerClassName为空的话，就只返回上一个界面，如果需要pop到其它controller的话，这里的controllerClassName不能为空
        if ([skipAction isEqualToString:@"pop"] &&(
            [controllerClassName isKindOfClass:[NSNull class]] ||
            controllerClassName == nil ||
            controllerClassName.length == 0)) {
            
            [nav popViewControllerAnimated:YES];
        }else{
            if (![controllerClassName isKindOfClass:[NSNull class]] && controllerClassName != nil && controllerClassName.length > 0) {
                
                Class class = NSClassFromString(controllerClassName);
                
                if (class == nil) {
                    CDVPluginResult *result = [CDVPluginResult resultWithStatus:CDVCommandStatus_CLASS_NOT_FOUND_EXCEPTION messageAsString:[NSString stringWithFormat:@"找不到对应的%@",controllerClassName]];
                    [self sendDataToJs:result withCallbackId:command.callbackId];
                }else{
                    
                    UIViewController *controller = [[class alloc] init];
                    controller.title = controllerTitle;
                    
                    if([skipAction isEqualToString:@"pop"]){
                        
                        // 是否在nav中找到controller
                        BOOL isFindContrller;
                        for (UIViewController *vc in nav.viewControllers) {
                            NSString *name = NSStringFromClass([vc class]);
                            if ([name isEqualToString:controllerClassName]) {
                                isFindContrller = YES;
                                controller = vc;
                                break;
                            }
                        }
                        
                        if (isFindContrller) {
                            [nav popToViewController:controller animated:YES];
                        }else{
                            CDVPluginResult *result = [CDVPluginResult resultWithStatus:CDVCommandStatus_CLASS_NOT_FOUND_EXCEPTION messageAsString:[NSString stringWithFormat:@"找不到对应的%@",controllerClassName]];
                            [self sendDataToJs:result withCallbackId:command.callbackId];
                        }
                        
                    }else if([skipAction isEqualToString:@"push"]){
                        [nav pushViewController:controller animated:YES];
                    }else if([skipAction isEqualToString:@"present"]){
                        [nav presentViewController:controller animated:YES completion:NULL];
                    }else{
                        CDVPluginResult *result = [CDVPluginResult resultWithStatus:CDVCommandStatus_CLASS_NOT_FOUND_EXCEPTION messageAsString:@"找不到对应动作"];
                        [self sendDataToJs:result withCallbackId:command.callbackId];
                    }
                }
                
            }else{
                CDVPluginResult *result = [CDVPluginResult resultWithStatus:CDVCommandStatus_CLASS_NOT_FOUND_EXCEPTION messageAsString:[NSString stringWithFormat:@"找不到对应的%@",controllerClassName]];
                [self sendDataToJs:result withCallbackId:command.callbackId];
            }
        }
        
        
    }else{
        CDVPluginResult *result = [CDVPluginResult resultWithStatus:CDVCommandStatus_NO_RESULT messageAsString:@"没有返回结果"];
        [self sendDataToJs:result withCallbackId:command.callbackId];
    }
    
//    CDVPluginResult *result;
//    
//    UIAlertController *controller;
//    
//    if ([command.arguments.firstObject isEqualToString:@"success"]) {
//        
//        result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:@"Success :)"];
//
//        [self.commandDelegate evalJs:[result argumentsAsJSON]];
//        
//        controller = [UIAlertController alertControllerWithTitle:command.arguments.firstObject message:@"你好啊" preferredStyle:UIAlertControllerStyleAlert];
//        UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:NULL];
//        UIAlertAction *confirm = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
//            [[HelloPlugin getRootViewController] pushViewController:[Test2ViewController new] animated:YES];    
//        }];
//        
//        [controller addAction:cancel];
//        [controller addAction:confirm];
//        
//    }else{
//        result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:@"Faild :("];
//        
//        [self.commandDelegate evalJs:[result argumentsAsJSON]];
//        
//        controller = [UIAlertController alertControllerWithTitle:command.arguments.firstObject message:@"不好啊" preferredStyle:UIAlertControllerStyleActionSheet];
//        
//        for (int i = 0; i < 4; i++) {
//            UIAlertAction *action = [UIAlertAction actionWithTitle:[NSString stringWithFormat:@"btn %d",i] style:UIAlertActionStyleDefault handler:NULL];
//            [controller addAction:action];
//        }
//        
//        UIAlertAction *action = [UIAlertAction actionWithTitle:@"删除" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
//            [[HelloPlugin getRootViewController] popViewControllerAnimated:YES];
//        }];
//        [controller addAction:action];
//    }
// 
//    NSLog(@"%@",[result argumentsAsJSON]);
//    
//    UIWindow *window = [UIApplication sharedApplication].windows.firstObject;
//    UIViewController *viewController = window.rootViewController;
//    [viewController presentViewController:controller animated:YES completion:NULL];
}

/**
 *  发送数据到js
 *
 *  @param result     <#result description#>
 *  @param callbackId <#callbackId description#>
 */
- (void)sendDataToJs:(CDVPluginResult *)result withCallbackId:(NSString *)callbackId{
    [self.commandDelegate sendPluginResult:result callbackId:callbackId];
}

-(void)nativeAppName:(id)obj{
    [[HelloPlugin getRootViewController] pushViewController:[TestViewController new] animated:YES];
}

+(UINavigationController *)getRootViewController{
    UIWindow *window = [UIApplication sharedApplication].windows.firstObject;
    if ([window.rootViewController isKindOfClass:[UINavigationController class]]) {
        UINavigationController *nav = (UINavigationController *)window.rootViewController;
        return nav;
    }
    return nil;
}
@end
