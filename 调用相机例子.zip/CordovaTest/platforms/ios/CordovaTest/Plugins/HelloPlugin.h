//
//  HelloPlugin.h
//  CordovaTest
//
//  Created by Mac on 15/12/15.
//
//

#import <Cordova/CDV.h>

@interface HelloPlugin : CDVPlugin

+ (UINavigationController *)getRootViewController;

- (void)nativeFunction:(id)arguments;

- (void)nativeAppName:(id)obj;

@end
