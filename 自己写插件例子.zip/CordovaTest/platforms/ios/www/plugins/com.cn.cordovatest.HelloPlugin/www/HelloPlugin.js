var HelloPlugin = {
    
callNativeFunction: function (success, fail, resultType) {

    return Cordova.exec( success, fail,
                        "HelloPlugin",
                        "nativeFunction",
                        [resultType]);
}
};

var HelloPlugin2 = {
callNativeAppName: function(success, fail, resultType){

    return Cordova.exec(success, fail, "HelloPlugin","nativeAppName",[resultType]);
}
};