//
//  Test2ViewController.h
//  CordovaTest
//
//  Created by Mac on 15/12/17.
//
//

#import <Cordova/CDVViewController.h>

@interface Test2ViewController : CDVViewController

@end
