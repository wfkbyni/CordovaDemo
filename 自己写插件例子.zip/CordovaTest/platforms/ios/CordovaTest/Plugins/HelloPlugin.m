//
//  HelloPlugin.m
//  CordovaTest
//
//  Created by Mac on 15/12/15.
//
//

#import "HelloPlugin.h"

#import "TestViewController.h"
#import "Test2ViewController.h"

@implementation HelloPlugin

- (void)nativeFunction:(id)arguments{
 
    CDVInvokedUrlCommand *command = arguments;
    
    NSLog(@"%@  %@   %@   %@",    command.arguments,command.methodName,command.className,command.callbackId);
    
    NSLog(@"Hello, this is a native function called from Cordova!");
    
    CDVPluginResult *result;
    
    UIAlertController *controller;
    
    if ([command.arguments.firstObject isEqualToString:@"success"]) {
        
        result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:@"Success :)"];

        [self.commandDelegate evalJs:[result argumentsAsJSON]];
        
        controller = [UIAlertController alertControllerWithTitle:command.arguments.firstObject message:@"你好啊" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:NULL];
        UIAlertAction *confirm = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [[HelloPlugin getRootViewController] pushViewController:[Test2ViewController new] animated:YES];    
        }];
        
        [controller addAction:cancel];
        [controller addAction:confirm];
        
    }else{
        result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:@"Faild :("];
        
        [self.commandDelegate evalJs:[result argumentsAsJSON]];
        
        controller = [UIAlertController alertControllerWithTitle:command.arguments.firstObject message:@"不好啊" preferredStyle:UIAlertControllerStyleActionSheet];
        
        for (int i = 0; i < 4; i++) {
            UIAlertAction *action = [UIAlertAction actionWithTitle:[NSString stringWithFormat:@"btn %d",i] style:UIAlertActionStyleDefault handler:NULL];
            [controller addAction:action];
        }
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:@"删除" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
            [[HelloPlugin getRootViewController] popViewControllerAnimated:YES];
        }];
        [controller addAction:action];
    }
 
    NSLog(@"%@",[result argumentsAsJSON]);
    
    UIWindow *window = [UIApplication sharedApplication].windows.firstObject;
    UIViewController *viewController = window.rootViewController;
    [viewController presentViewController:controller animated:YES completion:NULL];
}

-(void)nativeAppName:(id)obj{
    [[HelloPlugin getRootViewController] pushViewController:[TestViewController new] animated:YES];
}

+(UINavigationController *)getRootViewController{
    UIWindow *window = [UIApplication sharedApplication].windows.firstObject;
    if ([window.rootViewController isKindOfClass:[UINavigationController class]]) {
        UINavigationController *nav = (UINavigationController *)window.rootViewController;
        return nav;
    }
    return nil;
}
@end
